#include <stdio.h>
#include <stdlib.h>
#include "exerc2.h"

// Função que cria a pilha
PilhaDupla* criarPilha(int tamanho) {
    PilhaDupla* pilha = (PilhaDupla*)malloc(sizeof(PilhaDupla));
    if (pilha == NULL) {
        printf("Erro ao alocar memória para a pilha\n");
        exit(1);
    }
    // Inicializa o tamanho e topos A e B da pilha
    pilha->tamanho = tamanho;
    pilha->topA = -1;
    pilha->topB = tamanho;
    pilha->vetor = (int*)malloc(tamanho * sizeof(int)); // Aloca a memória de acordo com o tamanho escolhido

    // Mensagem caso ocorra um erro ao alocar
    if (pilha->vetor == NULL) {
        printf("Erro ao alocar memória para o vetor da pilha\n");
        free(pilha);
        exit(1);
    }

    return pilha;
}

// Função que adiciona valor na pilha A
void pushA(PilhaDupla* PilhaDupla, int data) {
    // Verifica se a pilha A está cheia
    if (PilhaDupla->topA + 1 == PilhaDupla->topB) {
        printf("\nA pilha A se encontra cheia\n\n");
        return;
    }
    // Adiciona valor na pilha
    PilhaDupla->vetor[++PilhaDupla->topA] = data;
}

// Função que adiciona valor na pilha B
void pushB(PilhaDupla* PilhaDupla, int data) {
    // Verifica se a pilha B está cheia
    if (PilhaDupla->topB - 1 == PilhaDupla->topA) {
        printf("\nA pilha B se encontra cheia\n\n");
        return;
    }
    // Adiciona valor na pilha
    PilhaDupla->vetor[--PilhaDupla->topB] = data;
}

// Função que remove valor da pilha A
int popA(PilhaDupla* PilhaDupla) {
    // Verifica se a pilha A está vazia
    if (PilhaDupla->topA == -1) {
        printf("\n\nPilha A vazia. Erro (underflow)\n");
        return -1;
    }
    // Remove valor na pilha
    int data = PilhaDupla->vetor[PilhaDupla->topA--];
    return data;
}

// Função que remove valor da pilha B
int popB(PilhaDupla* PilhaDupla) {
    // Verifica se a pilha B está vazia
    if (PilhaDupla->topB == PilhaDupla->tamanho) {
        printf("\n\nPilha B vazia. Erro (underflow)\n");
        return -1;
    }
    // Remove valor na pilha
    int data = PilhaDupla->vetor[PilhaDupla->topB++];
    return data;
}

// Função que remove todos os valores da pilha A
void clearA(PilhaDupla* PilhaDupla) {
    // Verifica se a pilha A está vazia
    if (PilhaDupla->topA == -1) {
        printf("\nA pilha A se encontra vazia\n");
    }
    // Remove todos os valorespresentes na pilha A
    while (PilhaDupla->topA != -1) {
        popA(PilhaDupla);
    }
}

// Função que remove todos os valores da pilha B
void clearB(PilhaDupla* PilhaDupla) {
    // Verifica se a pilha B está vazia
    if (PilhaDupla->topB == PilhaDupla->tamanho) {
        printf("\nA pilha B se encontra vazia\n");
    }
    // Remove todos os valorespresentes na pilha B
    while (PilhaDupla->topB != PilhaDupla->tamanho) {
        popB(PilhaDupla);
    }
}

// Função que imprime a pilha A
void imprimirA(PilhaDupla* PilhaDupla) {
    printf("[ ");
    for(int i = 0; i <= PilhaDupla->topA; i++) {
        printf("%d ", PilhaDupla->vetor[i]);
    }
    printf("]\n");
}

// Função que imprime a pilha B
void imprimirB(PilhaDupla* PilhaDupla) {
    printf("[ ");
    for(int i = PilhaDupla->tamanho - 1; i >= PilhaDupla->topB; i--) {
        printf("%d ", PilhaDupla->vetor[i]);
    }
    printf("]\n");
}
