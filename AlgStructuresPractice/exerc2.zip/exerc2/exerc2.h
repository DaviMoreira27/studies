#ifndef EXERC2_H_INCLUDED
#define EXERC2_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int tamanho;
    int topA; //Indica o topo de A
    int topB; //Indica o topo de B
    int* vetor; //Vetor compartilhado que armazenará os valores
} PilhaDupla;

PilhaDupla* criarPilha(int tamanho); //Função que cria a pilha

void pushA(PilhaDupla* PilhaDupla, int data); //Função que adiciona valor na pilha A

void pushB(PilhaDupla* PilhaDupla, int data); //Função que adiciona valor na pilha B

int popA(PilhaDupla* PilhaDupla); //Função que remove valor da pilha A

int popB(PilhaDupla* PilhaDupla); //Função que remove valor da pilha B

void clearA(PilhaDupla* PilhaDupla); //Função que remove todos os valores da pilha A

void clearB(PilhaDupla* PilhaDupla); //Função que remove todos os valores da pilha B

void imprimirA(PilhaDupla* PilhaDupla); //Função que imprime a pilha A

void imprimirB(PilhaDupla* PilhaDupla); //Função que imprime a pilha B

#endif // EXERC2_H_INCLUDED
