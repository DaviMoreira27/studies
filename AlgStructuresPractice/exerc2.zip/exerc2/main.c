#include <stdio.h>
#include <stdlib.h>
#include "exerc2.h"

int main() {
    int tamanho;

    // Solicitar o tamanho da pilha estática
    printf("Digite o tamanho desejado para a pilha: ");
    scanf("%d", &tamanho);

    // Cria a pilha com o tamanho desejado
    PilhaDupla* pilha = criarPilha(tamanho);

    // Adicionar valor na pilha A
    printf("\nPush A:(5)");
    pushA(pilha, 5);
    imprimirA(pilha);

    // Adicionar valor na pilha B
    printf("\nPush B:(3)");
    pushB(pilha, 3);
    imprimirB(pilha);

    // Adicionar valor na pilha A
    printf("\nPush A:(9)");
    pushA(pilha, 9);
    imprimirA(pilha);


    // Remove valor da pilha A
    printf("\nPop A");
    int valor = popA(pilha);
    imprimirA(pilha);

    // Remove valor da pilha B
    printf("\nPop B");
    valor = popB(pilha);
    imprimirB(pilha);

    //Teste underflow
    printf("\nPop B");
    valor = popB(pilha);
    imprimirB(pilha);

    // Adicionar valor na pilha A
    printf("\nPush A:(15)");
    pushA(pilha, 15);
    imprimirA(pilha);

    // Adicionar valor na pilha A
    printf("\nPush A:(7)");
    pushA(pilha, 7);
    imprimirA(pilha);

    // Remove todos os valores da pilha A
    printf("Clear A: ");
    clearA(pilha);
    imprimirA(pilha);

    // Adicionar valor na pilha B
    printf("\nPush B:(2)");
    pushB(pilha, 2);
    imprimirB(pilha);

    // Remove todos os valores da pilha B
    printf("\nClear B: ");
    clearB(pilha);
    imprimirB(pilha);

    // Testar funcionalidade da função com a pilha vazia
    printf("\nClear B: ");
    clearB(pilha);


    //Testes de Overflow
    printf("\nPush A:(15)");
    pushA(pilha, 15);
    imprimirA(pilha);

    printf("\nPush A:(6)");
    pushA(pilha, 6);
    imprimirA(pilha);

    printf("\nPush A:(98)");
    pushA(pilha, 98);
    imprimirA(pilha);

    printf("\nPush A:(10)");
    pushA(pilha, 10);
    imprimirA(pilha);

    printf("\nPush A:(3)");
    pushA(pilha, 3);
    imprimirA(pilha);

    printf("\nPush B:(40)");
    pushB(pilha, 40);
    imprimirB(pilha);

    printf("\nPush A:(15)");
    pushA(pilha, 15);
    imprimirA(pilha);

    printf("\nPush B:(12)");
    pushB(pilha, 12);
    imprimirB(pilha);

    free(pilha);

    return 0;
}
