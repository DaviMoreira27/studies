#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "exerc1.h"

// Função que cria uma fila com capacidade máxima determinada
Fila* criarFila(int capacity){
    Fila *fila = (Fila *)malloc(sizeof(Fila)); // Aloca memória para a estrutura de fila

    fila->capacity = capacity; // Define a capacidade máxima da fila
    fila->data = (char* )malloc(capacity * sizeof(char)); // Aloca memória para armazenar os dados da fila
    fila->front = -1; // Inicializa o índice do primeiro elemento como -1 (indicando fila vazia)
    fila->rear = -1;  // Inicializa o índice do último elemento como -1
    fila->size = 0;   // Inicializa o tamanho da fila como 0
}

// Retorna o tamanho atual da fila
int getSize(Fila *fila){
    return fila->size; // Retorna o número de elementos na fila
}

// Verifica se a fila está vazia
int isEmpty(Fila *fila){
    return fila->size == 0; // Retorna 1 se a fila estiver vazia, caso contrário retorna 0
}

// Verifica se a fila está cheia
int isFull(Fila *fila){
    return fila->size == fila->capacity; // Retorna 1 se a fila estiver cheia, caso contrário retorna 0
}

// Função para adicionar um elemento à fila
void enqueue(Fila *fila, char data) {
    if (fila->size >= fila->capacity) { // Verifica se a fila está cheia antes de adicionar
        printf("Erro. Overflow!"); // Mensagem de erro se a fila estiver cheia
        return;
    }

    // Atualiza os índices para inserir o novo elemento na fila
    if (fila->front == -1) {        // Se a fila estiver vazia
        fila->front = 0;  // Define o índice inicial
        fila->rear = 0;   // Define o índice final
    } else if (fila->rear == fila->capacity - 1) { // Se o rear atingir o final do array
        fila->rear = 0;   // Volta o rear para o início (fila circular)
    } else {
        fila->rear = fila->rear + 1;    // Move o rear para a próxima posição
    }

    fila->data[fila->rear] = data;      // Armazena o dado na posição correta
    fila->size += 1;                    // Incrementa o tamanho da fila
}

// Remove um elemento da fila (dequeue) e retorna seu valor
char dequeue(Fila *fila) {
    if (fila->size == 0) {              // Verifica se a fila está vazia
        printf("Erro. Underflow!");      // Mensagem de erro se a fila estiver vazia
        return -1;  // Retorna um valor inválido para indicar erro
    }

    char temp = fila->data[fila->front];    // Armazena o valor do elemento a ser removido

    if (fila->size == 1) {          // Se houver apenas um elemento na fila
        fila->front = -1;           // Reseta os índices da fila
        fila->rear = -1;
    } else if (fila->front == fila->capacity - 1) { // Se o front estiver no final do array
        fila->front = 0;                        // Volta o front para o início (fila circular)
    } else {
        fila->front = fila->front + 1;      // Move o front para a próxima posição
    }

    fila->size -= 1;            // Decrementa o tamanho da fila
    return temp;                // Retorna o valor removido da fila
}

// Retorna o valor do primeiro elemento da fila (sem removê-lo)
int getFront(Fila *fila) {
    if (isEmpty(fila)) {        // Verifica se a fila está vazia
        printf("Fila vazia\n"); // Exibe mensagem de fila vazia
        return -1;              // Retorna um valor inválido
    }
    return fila->data[fila->front]; // Retorna o valor do elemento da frente
}

// Função para limpar a fila
void clear(Fila *fila) {
    fila->front = -1; // Reseta o índice da frente
    fila->rear = -1;  // Reseta o índice traseiro
    fila->size = 0;   // Reseta o tamanho da fila
}

// Função auxiliar para imprimir a fila, utilizando uma fila auxiliar para preservar os dados
void imprimir(Fila *fila) {
    if (isEmpty(fila)) {    // Verifica se a fila está vazia
        printf("\n[ ]\n");
        return;
    }

    Fila* auxFila = criarFila(fila->capacity);  // Cria uma fila auxiliar para preservar os dados originais

    printf("\n[");
    while (!isEmpty(fila)) {        // Enquanto a fila não estiver vazia
        char front = dequeue(fila); // Remove o elemento da frente
        enqueue(auxFila, front);    // Armazena na fila auxiliar para não perder os dados
        printf(" %c", front);       // Imprime o elemento
    }
    printf(" ]\n");

    // Recupera os elementos da fila original a partir da fila auxiliar
    while (!isEmpty(auxFila)) {
        enqueue(fila, dequeue(auxFila));  // Reinsere os elementos na fila original
    }

    free(auxFila);  // Libera a memória da fila auxiliar
}

// Função que cria uma pilha
Pilha* criarPilha(){
    Pilha* pilha = (Pilha*)malloc(sizeof(Pilha));   // Aloca memória para a estrutura da pilha

    pilha->top = NULL;      // Inicializa o topo como NULL
    pilha->tamanho = 0;     // Inicializa o tamanho da pilha como 0
    return pilha;           // Retorna a pilha criada
}

// Função que cria um nó para a pilha
Node* criarNode(char data){
    Node* node = (Node*)malloc(sizeof(Node));  // Aloca memória para o nó da pilha

    node->data = data;    // Armazena o dado no nó
    node->next = NULL;    // Define o ponteiro para o próximo nó como NULL
    return node;          // Retorna o nó criado
}

// Função que verifica se a pilha está vazia
int isEmptyP(Pilha* pilha){
    return pilha->tamanho == 0;   // Retorna 1 se a pilha estiver vazia, caso contrário 0
}

// Função que empilha um elemento (push)
void push(Pilha* pilha, char data){
    Node* node = criarNode(data);   // Cria um novo nó
    node->next = pilha->top;    // Aponta o novo nó para o topo atual
    pilha->top = node;          // Atualiza o topo da pilha
    pilha->tamanho ++;          // Incrementa o tamanho da pilha
}

// Função que desempilha (pop)
char pop(Pilha* pilha){
    if(isEmptyP(pilha)){      // Verifica se a pilha está vazia
        printf("\nPilha vazia");
        return -1;            // Retorna valor inválido se estiver vazia
    }
    Node* temp = pilha->top;     // Salva o topo atual
    char data = temp->data;      // Armazena o dado do topo
    pilha->top = pilha->top->next;  // Atualiza o topo para o próximo nó
    free(temp); // Libera o nó removido
    pilha->tamanho --;      // Decrementa o tamanho da pilha
    return data;            // Retorna o dado removido
}

// Função que imprime a pilha
void imprimirPilha(Pilha* pilha){
    Pilha* auxPilha = criarPilha(); // Cria uma pilha auxiliar
    printf("\n[");

    // Remove os elementos da pilha original e imprime
    while (!isEmptyP(pilha)) {
        char data = pop(pilha);  // Remove o topo da pilha
        push(auxPilha, data);    // Armazena na pilha auxiliar
    }

    // Reinsere os elementos na pilha original
    while (!isEmptyP(auxPilha)) {
        char data = pop(auxPilha);  // Remove da pilha auxiliar
        push(pilha, data);          // Reinsere na pilha original
        printf(" %c", data);        // Imprime o elemento
    }
    printf(" ]\n");
    free(auxPilha);  // Libera a memória da pilha auxiliar
}

// Retorna o tamanho da pilha
int size(Pilha* pilha){
    return pilha->tamanho;
}

// Função que verifica o balanceamento de parênteses, colchetes e chaves na fila
int verificaBalanceamento(Fila* fila){

    Fila* filaAux = fila;            // Fila auxiliar para percorrer a fila original
    Pilha* pilha = criarPilha();      // Pilha para armazenar os símbolos de abertura

    while (filaAux->size != 0) {      // Enquanto houver elementos na fila
        if (filaAux->data[filaAux->front] == '(' || filaAux->data[filaAux->front] == '[' || filaAux->data[filaAux->front] == '{') {
            push(pilha, dequeue(filaAux));  // Empilha os símbolos de abertura
        } else if (!isEmptyP(pilha) &&
                   ((pilha->top->data == '(' && filaAux->data[filaAux->front] == ')') ||
                    (pilha->top->data == '[' && filaAux->data[filaAux->front] == ']') ||
                    (pilha->top->data == '{' && filaAux->data[filaAux->front] == '}'))) {
            dequeue(filaAux);       // Remove o símbolo de fechamento da fila
            pop(pilha);             // Remove o símbolo correspondente da pilha
        } else {
            printf("\nNão está organizado"); // Se houver um símbolo desbalanceado
            return 0;             // Retorna 0 para indicar desbalanceamento
        }
    }

    if (isEmptyP(pilha)) {  // Se a pilha estiver vazia no final, está balanceado
        return 1;           // Retorna 1 para indicar que está balanceado
    } else {
        printf("\nNão está organizado");
        return 0;
    }
}
