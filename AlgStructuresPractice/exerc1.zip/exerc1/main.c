#include <stdio.h>
#include <stdlib.h>
#include "exerc1.h"

#define CAPACITY 6

void testarFilaBalanceamento(char* input, int capacity) {
    Fila* fila = criarFila(capacity);

    // Inserindo os caracteres na fila
    for (int i = 0; i < capacity; i++) {
        enqueue(fila, input[i]);
    }

    // Imprimindo a fila atual
    printf("\nFila: ");
    imprimir(fila);

    // Verificando o balanceamento
    if (verificaBalanceamento(fila)) {
        printf("\nA fila está balanceada.\n");
    } else {
        printf("\nA fila não está balanceada.\n");
    }
}

int main() {
    // Teste 1: Fila balanceada com parênteses, colchetes e chaves
    printf("Teste 1:\n");
    testarFilaBalanceamento("([{()}])", 8);

    // Teste 2: Fila desbalanceada com símbolo faltando
    printf("Teste 2:\n");
    testarFilaBalanceamento("([{()}]", 7);

    // Teste 3: Fila desbalanceada com ordem errada
    printf("Teste 3:\n");
    testarFilaBalanceamento("{[(])}", 6);

    // Teste 4: Fila balanceada com parênteses apenas
    printf("Teste 4:\n");
    testarFilaBalanceamento("((()))", 6);

    // Teste 5: Fila desbalanceada com fechamento errado
    printf("Teste 5:\n");
    testarFilaBalanceamento("(()]", 4);

    // Teste 6: Entrada vazia (balanceada por padrão)
    printf("Teste 6:\n");
    testarFilaBalanceamento("", 0);

    return 0;
}
