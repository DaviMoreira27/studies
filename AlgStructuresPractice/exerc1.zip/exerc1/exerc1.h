#ifndef EXERC1_H_INCLUDED
#define EXERC1_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estrutura de Fila, usada para armazenar os dados a serem balanceados
typedef struct{
    int capacity;    // Capacidade máxima da fila
    char *data;      // Array para armazenar os caracteres
    int front;       // Índice do elemento da frente
    int rear;        // Índice do último elemento inserido
    int size;        // Tamanho atual da fila
}Fila;

// Função para criar a fila com uma determinada capacidade
Fila* criarFila(int capacity);

// Função para adicionar elementos na fila
void enqueue(Fila *fila, char data);

// Função para remover elementos da fila
char dequeue(Fila *fila);

// Função que retorna o tamanho atual da fila
int getSize(Fila *fila);

// Verifica se a fila está vazia
int isEmpty(Fila *fila);

// Verifica se a fila está cheia
int isFull(Fila *fila);

// Retorna o elemento na frente da fila
int getFront(Fila *fila);

// Limpa os elementos da fila
void clear(Fila *fila);

// Função para imprimir a fila
void imprimir(Fila *fila);

// Função para verificar o balanceamento dos símbolos na fila
int verificaBalanceamento(Fila *fila);

// Estrutura de Node (nó) para a pilha, usada para armazenar os símbolos de abertura
typedef struct Node{
    char data;         // Armazena o dado (símbolo)
    struct Node* next; // Ponteiro para o próximo nó
}Node;

// Estrutura da Pilha, usada no balanceamento dos símbolos
typedef struct{
    Node* top;       // Ponteiro para o topo da pilha
    int tamanho;     // Tamanho atual da pilha
}Pilha;

// Função para criar uma nova pilha
Pilha* criarPilha();

// Função para criar um novo nó da pilha
Node* criarNode(char data);

// Função que verifica se a pilha está vazia
int isEmptyP(Pilha* pilha);

// Função que empilha um elemento na pilha
void push(Pilha* pilha, char data);

// Função que desempilha o topo da pilha
char pop(Pilha* pilha);

// Função que retorna o tamanho da pilha
int size(Pilha* pilha);

// Retorna o topo da pilha (sem desempilhar)
char getTop(Pilha* pilha);

// Limpa a pilha
void clearP(Pilha* pilha);

// Imprime os elementos da pilha
void imprimirPilha(Pilha* pilha);

#endif // EXERC1_H_INCLUDED
