#include <stdio.h>
#include <stdlib.h>

#include "exerc6.h"

Node* createNode(int data){
    //Aloca a mem�ria
    Node* node = (Node*) malloc( sizeof(Node) );
    //Inicializa o no inserindo o valor e definindo seus subn�s como NULL
    node->data = data;
    node->left = NULL;
    node->right = NULL;

    return node;
}

Tree* createTree(){
    //Aloca a mem�ria
    Tree* tree = (Tree*) malloc( sizeof(Tree) );
    //Inicializa a raiz como NULL
    tree->root = NULL;
    return tree;
};

Node* insert( Node* node, int data ){
    //Verifica se o n� � nulo
    if (node == NULL){
        Node* newNode = createNode(data);
        printf("\n%d", newNode->data);
        return newNode;
    }

    // Verifica se vai para o lado esquerdo
    if (data < node->data){
        node->left = insert(node->left, data);
    }
    // vai para o lado direito
    else{
        node->right = insert(node->right, data);
    }

    printf("\n%d", node->data);
    return node;
}

int search( Node* node, int data ){
    //Verifica se o n� � nulo
    if (node == NULL){
        return 0;
    }
    //caso encontre, retorna 1 (o no faz parte da �rvore)
    if (data == node->data){
        return 1;
    }

    int achou;
    // Verifica se vai para o lado esquerdo
    if (data < node->data){
        achou = search(node->left, data);
    }
    // vai para o lado direito
    else{
        achou = search(node->right, data);
    }

    return achou;

}

Node* getMaxNode( Node* node ){
    //Verifica se o n� � nulo
    if (node == NULL){
        return NULL;
    }
    //Verifica se o n� a direita � nulo
    if (node->right == NULL){
        return node;
    }

    return getMaxNode( node->right );

}

Node* getMinNode( Node* node ){
    //Verifica se o n� � nulo
    if (node == NULL){
        return NULL;
    }
    //Verifica se o n� a esquerda � nulo
    if (node->left == NULL){
        return node;
    }

    return getMinNode( node->left );

}

Node* deleteNode( Node* node, int data,
                    char filhoSubstituto){
    //Verifica se o n� � nulo
    if (node == NULL){
        return node;
    }
    //Compara o valor com o valor do n� a esquerda e, se for menor que ele, segue para o n� a esquerda
    if (data < node->data){
        node->left = deleteNode( node->left, data,
                                      filhoSubstituto);
    }
    //Compara o valor com o valor do n� a direita e, se for maior que ele, segue para o n� a direita
    else if( data > node->data ){
         node->right = deleteNode( node->right, data,
                                      filhoSubstituto);
    }
    else{
        // encontrou o n� que sera excluido
        if(node->left == NULL){
            Node* tempNode = node->right;
            free(node);
            return tempNode;
        }
        //Verifica se o n� � nulo
        else if( node->right == NULL ){
            Node* tempNode = node->left;
            free(node);
            return tempNode;
        }
        else{
            // O n� possui dois filhos
            Node* tempNode;
            if( filhoSubstituto == 'D' ){
                // O menor de todos do lado direito
                tempNode = getMinNode(node->right);
                node->data = tempNode->data;
                node->right = deleteNode(node->right,
                                        tempNode->data,
                                        filhoSubstituto);
            }
            else{
                // O maior de todos do lado esquerdo
                tempNode = getMaxNode(node->left);
                node->data = tempNode->data;
                node->left = deleteNode(node->left,
                                        tempNode->data,
                                        filhoSubstituto);
            }
        }
    } // fecha o else

    return node;
}

// Fun��o para percorrer a �rvore em pr�-ordem
void strPreorder(Node *node){
    if( node != NULL ){

        printf("%d ", node->data );
        strPreorder(node->left);
        strPreorder(node->right);
    }
}


// Fun��o para percorrer a �rvore em ordem
void strInorder(Node *node) {
    if (node != NULL) {

        strInorder(node->left);
        printf("%d ", node->data);
        strInorder(node->right);
    }
}

// Fun��o para percorrer a �rvore em p�s-ordem
void strPostorder(Node *node) {
    if (node != NULL) {

        strPostorder(node->left);
        strPostorder(node->right);
        printf("%d ", node->data);
    }
}

int subnode(Node* node, int data) {
    // Verifica se o n� � nulo
    if (node == NULL) {
        return 0;
    }

    // Caso encontre o valor, come�a a contagem
    if (node->data == data) {
        int contador = 1; // Declara a vari�vel que conta os subn�s, considerando o n� atual
        if (node->left != NULL) {
            contador += subnode(node->left, node->left->data); // Conta subn�s � esquerda
        }
        if (node->right != NULL) {
            contador += subnode(node->right, node->right->data); // Conta subn�s � direita
        }
        return contador; // Retorna o valor final do contador de subn�s
    }

    if (data < node->data) {
        // Procura o n� na sub�rvore esquerda
        return subnode(node->left, data);
    } else {
        // Procura o n� na sub�rvore direita
        return subnode(node->right, data);
    }
}
