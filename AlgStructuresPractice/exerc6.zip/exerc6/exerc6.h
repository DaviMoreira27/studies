#ifndef EXERC6_H_INCLUDED
#define EXERC6_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
//Estrutura para os n�s que contem um valor e apontam para seus subn�s
typedef struct Node{

    int data;
    struct Node* left;
    struct Node* right;

} Node;

//Estrutura para a arvore, declarando o n� da raiz
typedef struct{
    Node* root;
}Tree;

//Fun��o para criar n�
Node* createNode(int data);

//Fun��o para criar �rvore
Tree* createTree();

//Fun��o para inserir n�
Node* insert( Node* node, int data );

//Fun��o para buscar valor
int search( Node* node, int data );

//Fun��o para obter o valor m�ximo
Node* getMaxNode( Node* node );

//Fun��o para obter o valor m�nimo
Node* getMinNode( Node* node );

//Fun��o para deletar n�
Node* deleteNode( Node* node, int data, char filhoSubstituto);

//Fun��o para obter a quantidade de subn�s
int subnode(Node* node, int data);

//Fun��es para imprimir a �rvore
void strPreorder(Node *node);
void strInorder(Node *node);
void strPostorder(Node *node);



#endif // EXERC6_H_INCLUDED
