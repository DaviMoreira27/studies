#include <stdio.h>
#include <stdlib.h>

#include "exerc6.h"

int main()
{

    Tree* tree = createTree();
    // Inserir n�meros
    printf("\n\nInsert 17");
    tree->root = insert(tree->root, 17);

    printf("\n\nInsert 6");
    tree->root = insert(tree->root, 6);

    printf("\n\nInsert 35");
    tree->root = insert(tree->root, 35);

    printf("\n\nInsert 4");
    tree->root = insert(tree->root, 4);

    printf("\n\nInsert 14");
    tree->root = insert(tree->root, 14);

    printf("\n\nInsert 23");
    tree->root = insert(tree->root, 23);

    printf("\n\nInsert 48");
    tree->root = insert(tree->root, 48);

    // Buscar n�mero
    printf("\n\nBuscar 14\n");
    int achou = search(tree->root, 14);
    printf("%d", achou);

    // Encontrar valor m�nimo
    Node* node = getMinNode(tree->root);
    printf("\n\nMenor: %d", node->data);

    // Encontrar valor m�ximo
    node = getMaxNode(tree->root);
    printf("\n\nMaior: %d", node->data);

    // Impress�o
    printf("\n\nPercurso pre-ordem\n");
    strPreorder(tree->root);

    printf("\n\nPercurso em-ordem\n");
    strInorder(tree->root);

    printf("\n\nPercurso pos-ordem\n");
    strPostorder(tree->root);

    // Remover n�
    printf("\n\ndeleteNode(4)\n");
    node = deleteNode(tree->root, 4, 'D');

    // Encontrar valor m�nimo
    node = getMinNode(tree->root);
    printf("\n\nMenor: %d", node->data);

    // Impress�o
    printf("\n\nPercurso pre-ordem\n");
    strPreorder(tree->root);

    printf("\n\nPercurso em-ordem\n");
    strInorder(tree->root);

    printf("\n\nPercurso pos-ordem\n");
    strPostorder(tree->root);

    // Contagem de subn�s
    printf("\n\nQuantidade de subnos do numero 17: %d", subnode(tree->root, 17));

    printf("\n\nQuantidade de subnos do numero 48: %d", subnode(tree->root, 48));

    printf("\n\nQuantidade de subnos do numero 4: %d", subnode(tree->root, 4));

    printf("\n\nQuantidade de subnos do numero 35: %d\n", subnode(tree->root, 35));
}
