#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

// Utilizo isso pra ter acesso ao ponteiro do nó encontrado e a um indicador me informando se foi encontrado ou não
// Isso facilita na hora de desenvolver a função de exclusão
TreeReturn* returnDefine(Node* node, int status) {
    TreeReturn* returnComponent = (TreeReturn*)malloc(sizeof(TreeReturn));
    returnComponent->node = node;
    // 1 se encontrado, 0 se não encontrado
    returnComponent->status = status;
    return returnComponent;
}

Node *createNode(int data) {
    Node *node = (Node*)malloc(sizeof(Node));

    if (node == NULL) {
        printf("Deu merda");
        exit(EXIT_FAILURE);
    }

    node->data = data;
    node->right = NULL;
    node->left = NULL;

    return node;
}

Tree *createTree() {
    Tree *tree = (Tree*)malloc(sizeof(Tree));

    if (tree == NULL) {
        printf("Deu merda");
        exit(EXIT_FAILURE);
    }

    tree->root = NULL;

    return tree;
}

Node *insertTree (Node *node, int data) {
    if (node == NULL) {
        Node *newNode = createNode(data);
        return newNode;
    }

    if (data < node->data) {
        node->left = insertTree(node->left, data);
    }

    if (data >= node->data) {
        node->right = insertTree(node->right, data);
    }

    // printf("%i \n", node->data);
    return node;
}

TreeReturn *searchTree(Node *node, int data) {
    if (node == NULL) {
        printf("Arvore nula");
        return returnDefine(NULL, 0);
    }

    if (data == node->data) {
        return returnDefine(node, 1);
    }

    if (data < node->data) {
        return searchTree(node->left, data);
    }

    if (data >= node->data) {
        return searchTree(node->right, data);
    }

    return returnDefine(NULL, 0);
}

void printTree(Node *node) {
    if (node == NULL) {
        return;
    }
    // Intra ordem
    printTree(node->left);
    printf("\n%i\n", node->data);
    printTree(node->right);

    return;
}

// Fiz por causa de um leetcode
void invertTree(Node *node) {
    if (node == NULL) {
        return;
    }

    Node *tempLeft = node->left;
    node->left = node->right;
    node->right = tempLeft;
    invertTree(node->left);
    invertTree(node->right);

    return;
}

Node *getMinNode (Node *node) {
    if (node == NULL) {
        return NULL;
    }

    if (node->left == NULL) {
        // Encontra o último nó
        return node;
    }

    return getMinNode(node->left);
}

Node *getMaxNode (Node *node) {
    if (node == NULL) {
        return NULL;
    }

    if (node->right == NULL) {
        // Encontra o último nó
        return node;
    }

    return getMaxNode(node->right);
}

Node *removeNode (Node *node, int data) {
    TreeReturn *searchedNode = searchTree(node, data);

    if (searchedNode->status == 0) {
        printf("Não enconrrado");
        return node;
    }

    // Se o nó encontrado não tiver filhos (nó folha), apenas libera
    if (searchedNode->node->left == NULL && searchedNode->node->right == NULL) {
        free(searchedNode->node);
        return node;  // Retorna a árvore sem o nó removido, pois já foi liberado
    }

    // Se o nó encontrado tem apenas o filho da direita, remove o nó e conecta o filho direito
    if (searchedNode->node->left == NULL && searchedNode->node->right != NULL) {
        Node *tempNode = searchedNode->node->right;
        free(searchedNode->node);
        return tempNode;  // Retorna o nó filho direito para substituir o nó removido
    }

    // Se o nó encontrado tem apenas o filho da esquerda, remove o nó e conecta o filho esquerdo
    if (searchedNode->node->right == NULL && searchedNode->node->left != NULL) {
        Node *tempNode = searchedNode->node->left;
        free(searchedNode->node);
        return tempNode;
    }

    // CASO O NÓ TENHA DOIS FILHOS

    /*

            50
           /  \
         30    70
        /  \
      20    40
            /
          35


        50
       /  \
     20    70
       \
       40
       /
     35
    */

    // Pego o maior nó da subárvore esquerda
    Node *maxNode = getMaxNode(searchedNode->node->left);
    // Assinalo esse valor ao nó encontrado que será deletado
    searchedNode->node->data = maxNode->data;
    // Removo o nó esquerdo com maior valor
    searchedNode->node->left = removeNode(searchedNode->node->left, maxNode->data);

    return node;
}

// Função que cria um novo nó de lista com a soma fornecida e retorna o ponteiro para o nó criado
ListNode* createListNode(int sum) {
    ListNode* newListNode = (ListNode*)malloc(sizeof(ListNode));
    // Inicializa o valor do nó com a soma fornecida
    newListNode->sum = sum;
    newListNode->next = NULL;

    // Retorna o ponteiro para o novo nó de lista
    return newListNode;
}

// Função que calcula as somas dos caminhos da raiz até as folhas da árvore binária
ListNode* calculatePaths(Node* node, int currentSum) {
    // Se o nó for nulo, retorna NULL
    if (node == NULL) {
        return NULL;
    }

    // Adiciona o valor do nó atual à soma acumulada
    currentSum += node->data;

    // Caso o nó seja uma folha (não tem filhos), cria um nó de lista com a soma do caminho até essa folha
    if (node->left == NULL && node->right == NULL) {
        ListNode* leafNode = createListNode(currentSum);  // Cria um novo nó de lista com a soma do caminho
        return leafNode;
    }

    // Chama a função para as subárvores esquerda e direita
    ListNode* leftList = calculatePaths(node->left, currentSum);
    ListNode* rightList = calculatePaths(node->right, currentSum);

    // Se não houver caminho na subárvore esquerda, retorna a lista da subárvore direita
    if (leftList == NULL) {
        return rightList;
    }

    // Se houver caminhos na subárvore esquerda, conecta os caminhos da subárvore direita ao final da lista da esquerda
    ListNode* current = leftList;
    while (current->next != NULL) {
        current = current->next;
    }
    current->next = rightList;

    return leftList;
}

// Função que imprime todos os caminhos da árvore da raiz até as folhas, mostrando as somas
void caminhos(Node* tree) {
    // Calcula todos os caminhos a partir da raiz até as folhas
    ListNode* head = calculatePaths(tree, 0);

    // Se não houver caminhos, a árvore está vazia, imprime uma lista vazia
    if (head == NULL) {
        printf("[]\n");
        return;
    }

    // Caso contrário, imprime todos os caminhos na lista
    ListNode* current = head;
    printf("[");
    while (current != NULL) {
        printf("%d", current->sum);  // Imprime a soma de cada caminho
        current = current->next;
        if (current != NULL) {
            printf(", ");
        }
    }
    printf("]\n");

    // Limpa tudo
    while (head != NULL) {
        ListNode* temp = head;
        head = head->next;
        free(temp);
    }
    return;
}
