#include <stdio.h>
#include "tree.h"

int main()
{

    Tree* tree = createTree();

    tree->root = insertTree(tree->root, 61);
    tree->root = insertTree(tree->root,34);
    tree->root = insertTree(tree->root, 19);
    tree->root = insertTree(tree->root, 20);
    tree->root = insertTree(tree->root, 50);
    tree->root = insertTree(tree->root, 55);
    tree->root = insertTree(tree->root, 67);
    tree->root = insertTree(tree->root, 66);
    tree->root = insertTree(tree->root, 64);
    tree->root = insertTree(tree->root, 94);
    tree->root = insertTree(tree->root, 70);
    tree->root = insertTree(tree->root, 95);
    // tree->root = insertTree(tree->root, 8451);


    printTree(tree->root);
    caminhos(tree->root);

    TreeReturn* result = searchTree(tree->root, 95);
    if (result->node != NULL) {
        printf("SEARCH: %d\n", result->node->data);
    } else {
        printf("Nao encontrado\n");
    }
    printf("MIN NODE: %d\n", getMinNode(tree->root)->data);
    printf("MAX NODE: %d\n", getMaxNode(tree->root)->data);

    invertTree(tree->root);

    return 1;
}
