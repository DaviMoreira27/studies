#include "exerc5.h"
#include <stdio.h>
#include <stdlib.h>

// funcao para criar um novo node
Node* criarNode(int data) {
    Node* novo = (Node*) malloc(sizeof(Node));
    novo->data = data;
    novo->proxLinha = NULL;
    novo->proxColuna = NULL;
    return novo;
}

// Funcao para criar uma matriz esparsa
MatrizEsparsa* criarMatriz(int numLinhas, int numColunas) {
    MatrizEsparsa* matriz = (MatrizEsparsa*) malloc(sizeof(MatrizEsparsa));
    matriz->numLinhas = numLinhas;
    matriz->numColunas = numColunas;

    // Aloca arrays de ponteiros para as listas de linhas e colunas
    matriz->linhas = (Node**) calloc(numLinhas, sizeof(Node*));
    matriz->colunas = (Node**) calloc(numColunas, sizeof(Node*));

    return matriz;
}

// Funcao para inserir um valor na matriz esparsa
void insert(MatrizEsparsa* matriz, int linha, int coluna, int data) {
    if (data == 0) {
        removeElemento(matriz, linha, coluna); // Remove o n� se o valor for zero
        return;
    }

    // Insere ou atualiza o node na lista da linha
    Node* atual = matriz->linhas[linha];
    Node* anterior = NULL;

    // Encontrar a posicao correta na linha
    while (atual != NULL && atual->coluna < coluna) {
        anterior = atual;
        atual = atual->proxLinha;
    }

    // Se o node ja existe, atualiza o valor
    if (atual != NULL && atual->coluna == coluna) {
        atual->data = data;
    } else {
        Node* novo = criarNode(data);
        novo->linha = linha;
        novo->coluna = coluna;

        // Ajusta os ponteiros para inserir o novo node na linha
        if (anterior == NULL) {
            matriz->linhas[linha] = novo;
        } else {
            anterior->proxLinha = novo;
        }
        novo->proxLinha = atual;

        // Agora, insere o node na coluna correspondente
        Node* atualCol = matriz->colunas[coluna];
        Node* anteriorCol = NULL;

        while (atualCol != NULL && atualCol->linha < linha) {
            anteriorCol = atualCol;
            atualCol = atualCol->proxColuna;
        }

        if (anteriorCol == NULL) {
            matriz->colunas[coluna] = novo;
        } else {
            anteriorCol->proxColuna = novo;
        }
        novo->proxColuna = atualCol;
    }
}

void removeElemento(MatrizEsparsa* matriz, int linha, int coluna) {
    // funcao para remover um valor da matriz esparsa
    Node* atual = matriz->linhas[linha];
    Node* anterior = NULL;

    // Remover da lista da linha
    while (atual != NULL && atual->coluna != coluna) {
        anterior = atual;
        atual = atual->proxLinha;
    }

    if (atual == NULL) return;  // Elemento nao encontrado

    // Ajusta ponteiros para remocao na lista da linha
    if (anterior == NULL) {
        matriz->linhas[linha] = atual->proxLinha;
    } else {
        anterior->proxLinha = atual->proxLinha;
    }

    // Agora remover da lista da coluna
    Node* atualCol = matriz->colunas[coluna];
    Node* anteriorCol = NULL;

    while (atualCol != NULL && atualCol->linha != linha) {
        anteriorCol = atualCol;
        atualCol = atualCol->proxColuna;
    }

    if (anteriorCol == NULL) {
        matriz->colunas[coluna] = atual->proxColuna;
    } else {
        anteriorCol->proxColuna = atual->proxColuna;
    }

    free(atual); // Liberar memoria do node removido
}

// funcao para buscar um valor na matriz esparsa
int buscar(MatrizEsparsa* matriz, int linha, int coluna) {
    Node* atual = matriz->linhas[linha];

    // Percorrer a lista da linha ate encontrar a coluna
    while (atual != NULL && atual->coluna != coluna) {
        atual = atual->proxLinha;
    }

    return (atual == NULL) ? 0 : atual->data;
}

// funcao para imprimir a matriz completa
int imprimir(MatrizEsparsa* matriz) {
    for (int i = 0; i < matriz->numLinhas; i++) {
        for (int j = 0; j < matriz->numColunas; j++) {
            int valor = buscar(matriz, i, j);
            printf("%d ", valor);
        }
        printf("\n");
    }
    return 0;
}

// funcao para somar duas matrizes esparsas e retornar uma nova matriz
MatrizEsparsa* somar(MatrizEsparsa* matriz1, MatrizEsparsa* matriz2) {
    if (matriz1->numLinhas != matriz2->numLinhas || matriz1->numColunas != matriz2->numColunas) {
        printf("Erro: Matrizes de tamanhos diferentes!\n");
        return NULL;
    }

    MatrizEsparsa* resultado = criarMatriz(matriz1->numLinhas, matriz1->numColunas);

    for (int i = 0; i < matriz1->numLinhas; i++) {
        for (int j = 0; j < matriz1->numColunas; j++) {
            int valor1 = buscar(matriz1, i, j);
            int valor2 = buscar(matriz2, i, j);
            int soma = valor1 + valor2;
            if (soma != 0) {
                insert(resultado, i, j, soma);
            }
        }
    }

    return resultado;
}

// funcao para somar todos os valores internos da matriz
int somaInterna(MatrizEsparsa* matriz) {
    int soma = 0;
    for (int i = 0; i < matriz->numLinhas; i++) {
        Node* atual = matriz->linhas[i];
        while (atual != NULL) {
            soma += atual->data;
            atual = atual->proxLinha;
        }
    }
    return soma;
}

// funcao para calcular a esparsidade da matriz (retorna a proporcao de zeros)
float calculaEsparsidade(MatrizEsparsa* matriz) {
    int totalElementos = matriz->numLinhas * matriz->numColunas;
    int naoNulos = 0;

    for (int i = 0; i < matriz->numLinhas; i++) {
        Node* atual = matriz->linhas[i];
        while (atual != NULL) {
            naoNulos++;
            atual = atual->proxLinha;
        }
    }

    return (float)(totalElementos - naoNulos) / totalElementos;
}
