#ifndef EXERC5_H_INCLUDED
#define EXERC5_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

typedef struct Node{
    int linha;
    int coluna;
    int data;

    struct Node* proxLinha;
    struct Node* proxColuna;
}Node;

typedef struct{
    Node** linhas;
    Node** colunas;
    int numLinhas;
    int numColunas;
}MatrizEsparsa;

Node* criarNode(int data);

MatrizEsparsa* criarMatriz(int numLinhas, int numColunas);

void insert(MatrizEsparsa* matriz,int linha, int coluna, int data);

void removeElemento(MatrizEsparsa* matriz,int linha, int coluna);

int buscar(MatrizEsparsa* matriz,int linha, int coluna);

int imprimir(MatrizEsparsa* matriz);

MatrizEsparsa* somar(MatrizEsparsa* matriz1, MatrizEsparsa* matriz2);

int somaInterna(MatrizEsparsa* matriz);

float calculaEsparsidade(MatrizEsparsa* matriz);


#endif // EXERC5_H_INCLUDED
