#include "exerc5.h"
#include <stdio.h>
#include "exerc5.h"

int main() {
    // Teste 1: Criar matriz esparsa e inserir valores
    MatrizEsparsa* matriz1 = criarMatriz(4, 4); // 4x4 matriz
    printf("Teste 1: Insercao de valores em matriz 4x4\n");
    insert(matriz1, 0, 0, 5);
    insert(matriz1, 1, 1, 10);
    insert(matriz1, 0, 1, 27);
    insert(matriz1, 2, 2, 15);
    insert(matriz1, 3, 3, 20);
    imprimir(matriz1);

    // Teste 2: Atualizar um valor existente e inserir mais valores
    printf("\nTeste 2: Atualizando valor e inserindo novos valores\n");
    insert(matriz1, 0, 0, 7);  // Atualiza valor (0, 0)
    insert(matriz1, 0, 1, 25); // Insere novo valor (0, 1)
    imprimir(matriz1);

    // Teste 3: Remover um valor e ver como a matriz se comporta
    printf("\nTeste 3: Remover valor na posicao (0, 0)\n");
    removeElemento(matriz1, 0, 0);  // Remove valor na posicao (0, 0)
    imprimir(matriz1);

    // Teste 4: Buscar valores existentes e inexistentes
    printf("\nTeste 4: Buscar valores na matriz\n");
    printf("Valor na posicao (2, 2): %d\n", buscar(matriz1, 2, 2));  // Deve retornar 15
    printf("Valor na posicao (0, 0): %d\n", buscar(matriz1, 0, 0));  // Deve retornar 0 (foi removido)
    printf("Valor na posicao (1, 1): %d\n", buscar(matriz1, 1, 1));  // Deve retornar 10
    printf("Valor na posicao (3, 3): %d\n", buscar(matriz1, 3, 3));  // Deve retornar 20

    // Teste 5: Criar outra matriz e somar duas matrizes
    MatrizEsparsa* matriz2 = criarMatriz(4, 4);
    insert(matriz2, 0, 0, 1);
    insert(matriz2, 1, 1, 2);
    insert(matriz2, 2, 2, 3);
    insert(matriz2, 3, 3, 4);
    printf("\nMatriz 2 (a ser somada):\n");
    imprimir(matriz2);

    MatrizEsparsa* matrizSoma = somar(matriz1, matriz2);
    printf("\nTeste 5: Soma das matrizes 1 e 2\n");
    imprimir(matrizSoma);

    // Teste 6: Calcular soma interna da matriz
    printf("\nTeste 6: Soma interna da Matriz 1\n");
    int soma1 = somaInterna(matriz1);
    printf("Soma interna da Matriz 1: %d\n", soma1);

    // Teste 7: Calcular esparsidade da matriz
    printf("\nTeste 7: Esparsidade da Matriz 1\n");
    float esparsidade1 = calculaEsparsidade(matriz1);
    printf("Esparsidade da Matriz 1: %.2f\n", esparsidade1);

    printf("\nTeste 8: Esparsidade da Matriz Soma\n");
    float esparsidadeSoma = calculaEsparsidade(matrizSoma);
    printf("Esparsidade da Matriz Soma: %.2f\n", esparsidadeSoma);

    return 0;
}
