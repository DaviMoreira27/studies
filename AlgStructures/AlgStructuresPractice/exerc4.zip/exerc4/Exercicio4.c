#include "exercicio4.h"

#include <stdio.h>
#include <stdlib.h>

//criacao da variavel que informa se o vetor está ordenado ou nao
int ordenado_1 = 0;

//funcao de criar no
Node* criarNode(int data) {
    Node* novoNode = (Node*)malloc(sizeof(Node));
    if (novoNode == NULL) {
        printf("Erro ao alocar memoria!\n");
        exit(1);
    }
    novoNode->data = data;
    novoNode->next = NULL;
    novoNode->prev = NULL;
    return novoNode;
}
//criar lista
Lista* criarLista() {
    Lista* lista = (Lista*)malloc(sizeof(Lista));
    if (lista == NULL) {
        printf("Erro ao alocar memoria!\n");
        exit(1);
    }
    lista->head = NULL;
    lista->tail = NULL;
    lista->size = 0;
    return lista;
}
//pegar o tamanho
int getSize(Lista* lista){
    return lista->size;
}
//verifica se a lista esta vazia
int isEmpty(Lista* lista){
    return getSize(lista)==0;
}
//insere um elemento no topo da lista
void insertHead(Lista* lista, int data){
    Node* newNode = criarNode(data);
    if (getSize(lista)==0){
        lista->head = newNode;
        lista->tail = newNode;
    }
    else{
        newNode->next = lista->head;
        lista->head->prev = newNode;
        lista->head = newNode;
    }
    lista->size++;
    ordenado_1 = 0; // Marca a lista como não ordenada
}
//insere um elemento no final da lista
void insertTail(Lista* lista, int data){
    if(isEmpty(lista)){
        insertHead(lista, data);
    }
    else{
        Node* newNode = criarNode(data);
        newNode->prev = lista->tail;
        lista->tail->next = newNode;
        lista->tail = newNode;
        lista->size++;
    }
    ordenado_1 = 0; // Marca a lista como não ordenada
}
//insere um elemento em uma posicao desejada
void insert(Lista* lista, int data, int position){
    if(position <= getSize(lista)){
        if(position == 0){
            insertHead(lista, data);
        }
        else if(position == getSize(lista)){
            insertTail(lista, data);
        }
        else{
            Node* newNode = criarNode(data);
            Node* auxNode = lista->head;
            for(int i = 0; i < position - 1; i++){
                auxNode = auxNode->next;
            }
            newNode->prev = auxNode;
            newNode->next = auxNode->next;
            auxNode->next->prev = newNode;
            auxNode->next = newNode;
            lista->size++;
        }
    }
    ordenado_1 = 0;
}
//remove o elemento do começo da lista
void removeHead(Lista* lista){
    if (isEmpty(lista)){
        printf("Erro. Underflow!");
        return;
    }
    Node* nodeRemover = lista->head;
    if (getSize(lista) == 1){
        lista->tail = NULL;
        lista->head = NULL;
    }
    else{
        lista->head = nodeRemover->next;
        lista->head->prev = NULL;
    }
    lista->size--;
    free(nodeRemover);
}
//remove o elemento do final da lista
void removeTail(Lista* lista){
    if (isEmpty(lista)){
        printf("Erro. Underflow!");
        return;
    }
    Node* nodeRemover = lista->tail;
    if (getSize(lista) == 1){
        lista->tail = NULL;
        lista->head = NULL;
    }
    else{
        lista->tail = nodeRemover->prev;
        lista->tail->next = NULL;
    }
    lista->size--;
    free(nodeRemover);
}
//remove o elemento em uma posicao desejada
void removeNode(Lista* lista, int position){
    if (isEmpty(lista)){
        printf("Erro. Underflow!");
        return;
    }
    if (position < 0 || position >= getSize(lista)){
        printf("Posição inválida!");
        return;
    }
    if (position == 0){
        removeHead(lista);
        return;
    }
    if (position == getSize(lista) - 1){
        removeTail(lista);
        return;
    }
    Node* tempNode = lista->head;
    int i = 0;
    while(tempNode != NULL){
        if (i == position){
            tempNode->prev->next = tempNode->next;
            tempNode->next->prev = tempNode->prev;
            break;
        }
        tempNode = tempNode->next;
        i++;
    }
    lista->size--;
    free(tempNode);
}
//Procura pot um elemento especifico na lista
int busca(Lista* lista, int data){
    if(ordenado_1 == 0){
        Node* tempNode = lista->head;
        for(int i = 0; i < getSize(lista); i++){
            if(tempNode->data == data){
                return i;
            }
            tempNode = tempNode->next;
        }
    } else {
        int* array = Ordenado(lista);
        int result = BuscaBinaria(array, getSize(lista), data);
        free(array);  // Libera o array alocado
        return result;
    }
    return -1;
}
//remove todos os elementos da lista
void clear(Lista* lista){
    while(getSize(lista) > 0){
        removeHead(lista);
    }
}
//imprime a lista
void printLista(Lista* lista){
    Node* nohAtual = lista->head;
    if(getSize(lista) == 0){
        printf("\n[]");
        return;
    }
    printf("\n[");
    while(nohAtual->next != NULL){
        printf(" %d ", nohAtual->data);
        nohAtual = nohAtual->next;
    }
    printf(" %d ", nohAtual->data);
    printf("]");
}
//ordena a lista
int* Ordenado(Lista* lista) {
    int n = lista->size;
    int* array = (int*)malloc(n * sizeof(int));
    if (array == NULL) {
        printf("Erro ao alocar memoria!\n");
        exit(1);
    }

    // transforma a lista em um array para ordenar ele sem problemas
    Node* current = lista->head;
    for (int i = 0; i < n; i++) {
        array[i] = current->data;
        current = current->next;
    }

    // Ordenação decrescente da lista
    for (int j = n; j > 0; j--) {
        for (int i = 0; i < j - 1; i++) {
            if (array[i] < array[i + 1]) {
                int temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
            }
        }
    }

    ordenado_1 = 1;
    return array;
}
//busca binaria
int BuscaBinaria(int a[], int n, int x) {
    return AuxilioBB(a, 0, n - 1, x);
}
//auxilio da busca binaria
int AuxilioBB(int a[], int c, int f, int x) {
    if(c > f) {
        return -1;
    }
    int m = (c + f) / 2;
    if(x == a[m]) {
        return m;
    }
    if(x > a[m]) {
        return AuxilioBB(a, m + 1, f, x);
    }
    return AuxilioBB(a, c, m - 1, x);
}
