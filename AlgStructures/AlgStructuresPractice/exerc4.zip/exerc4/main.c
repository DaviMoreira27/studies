#include "exercicio4.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    // Criando uma lista
    Lista* lista = criarLista();

    // Inserindo elementos na lista
    insertTail(lista, 5);
    insertTail(lista, 10);
    insertTail(lista, 3);
    insertHead(lista, 15);
    insert(lista, 7, 2); // Inserindo o valor 7 na posicao 2

    // Imprimindo a lista apos insercoes
    printf("Lista apos insercoes:");
    printLista(lista);

    // Removendo elementos
    removeHead(lista);     
    removeTail(lista);    
    removeNode(lista, 1);  

    // Imprimindo a lista apos remocoes
    printf("\nLista apos remocoes:");
    printLista(lista);

    // Testando a busca de um elemento
    int posicao = busca(lista, 10);
    printf("\nBusca pelo elemento 10: ");
    if (posicao != -1) {
        printf("Encontrado na posicao %d", posicao);
    } else {
        printf("Elemento nao encontrado");
    }

    // Ordenando a lista
    int* arrayOrdenado = Ordenado(lista);
    printf("\nLista convertida em array e ordenada em ordem decrescente:");
    for (int i = 0; i < lista->size; i++) {
        printf(" %d", arrayOrdenado[i]);
    }

    // Teste da busca binaria depois de ordenar o array
    int valor = 10;
    int resultadoBuscaBinaria = BuscaBinaria(arrayOrdenado, lista->size, valor);
    if (resultadoBuscaBinaria != -1) {
        printf("encontramos o valor na posicao %d", resultadoBuscaBinaria);
    } else {
        printf("Valor nao encontrado");
    }

    free(arrayOrdenado);
    clear(lista);
    free(lista);

    return 0;
}
