#ifndef EXERCICIO4_H_INCLUDED
#define EXERCICIO4_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

// Estrutura de um no da lista duplamente ligada
typedef struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
} Node;

// Estrutura da lista duplamente ligada
typedef struct Lista {
    Node* head;
    Node* tail;
    int size;
} Lista;

// Funcao para criar um novo no
Node* criarNode(int data);

// Funcao para inicializar uma lista duplamente ligada
Lista* criarLista();

// Funcao para adicionar um elemento no inicio da lista
void insertHead(Lista* lista, int data);

// Funcao para adicionar um elemento no final da lista
void insertTail(Lista* lista, int data);

// Funcao para buscar um elemento na lista
int busca(Lista* lista, int data);

// Funcao para inserir um elemento em uma posicao especifica da lista
void insert(Lista* lista, int data, int position);

// Funcao para remover um elemento da lista
void removeHead(Lista* lista);

// Funcao para remover um elemento da lista
void removeTail(Lista* lista);

// Funcao para remover um elemento da lista
void removeNode(Lista* lista, int position);

// Funcao para limpar a lista
void clear(Lista* lista);

// Funcao para verificar se a lista esta vazia
int isEmpty(Lista* lista);

// Funcao para retornar o tamanho da lista
int getSize(Lista* lista);

// Funcao para imprimir a lista
void printLista(Lista* lista);

// Funcao para realizar a busca binaria
int BuscaBinaria(int a[], int n, int x);

// funcao auxiliar da busca binaria
int AuxilioBB(int a[], int c, int f, int x);

//funcao para ordenar a lista
int* Ordenado(Lista* lista);

#endif // EXERCICIO4_H_INCLUDED

